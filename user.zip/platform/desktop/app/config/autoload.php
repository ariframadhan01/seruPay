<?php
require_once ENTITIES_DESKTOPPATH.'app.php';

$init = [
    'App\Entities\Auth'
];

new App($init);