<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/platform/desktop/app/config/constant.php';
require_once SYSTEMPATH.'/connect.php';
require_once 'autoload.php';
require_once HELPER_DESKTOPPATH.'main.php';
