<?php

defined('SYSTEMPATH') || define('SYSTEMPATH', $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR);
defined('DESKTOPPATH') || define('DESKTOPPATH', SYSTEMPATH . 'platform/desktop/');
defined('APP_DESKTOPPATH') || define('APP_DESKTOPPATH', SYSTEMPATH . 'platform/desktop/app/');
defined('CONFIG_DESKTOPPATH') || define('CONFIG_DESKTOPPATH', SYSTEMPATH . 'platform/desktop/app/config/');
defined('ENTITIES_DESKTOPPATH') || define('ENTITIES_DESKTOPPATH', SYSTEMPATH . 'platform/desktop/app/entities/');
defined('HELPER_DESKTOPPATH') || define('HELPER_DESKTOPPATH', SYSTEMPATH . 'platform/desktop/app/helpers/');