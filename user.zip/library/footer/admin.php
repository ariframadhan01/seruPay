               </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <footer class="iq-footer">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                    <?= date('Y') ?> © <a href="<?= base_url() ?>"><?= $_CONFIG['title'] ?></a>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer END -->
<? require _DIR_('library/modal') ?>
      <!-- color-customizer -->
      <div class="iq-colorbox color-fix">
         <div class="buy-button"> <a class="color-full" href="#"><i class="fa fa-spinner fa-spin"></i></a> </div>
         <div id="right-sidebar-scrollbar" class="iq-colorbox-inner">
            <div class="clearfix color-picker">
               <h3 class="iq-font-black"><?= $_CONFIG['title'] ?> Awesome Color</h3>
               <p>Kombo Warna Ini Tersedia Di Dalam Keseluruhan Template. Anda Dapat Mengubah Keinginan Anda, Bahkan Anda Dapat Membuat Sendiri Dengan Kemungkinan Yang Tidak Terbatas!</p>
               <ul class="iq-colorselect clearfix">
                  <li class="color-1 iq-colormark" data-style="color-1"></li>
                  <li class="color-2" data-style="iq-color-2"></li>
                  <li class="color-3" data-style="iq-color-3"></li>
                  <li class="color-4" data-style="iq-color-4"></li>
                  <li class="color-5" data-style="iq-color-5"></li>
                  <li class="color-6" data-style="iq-color-6"></li>
                  <li class="color-7" data-style="iq-color-7"></li>
                  <li class="color-8" data-style="iq-color-8"></li>
                  <li class="color-9" data-style="iq-color-9"></li>
                  <li class="color-10" data-style="iq-color-10"></li>
                  <li class="color-11" data-style="iq-color-11"></li>
                  <li class="color-12" data-style="iq-color-12"></li>
                  <li class="color-13" data-style="iq-color-13"></li>
                  <li class="color-14" data-style="iq-color-14"></li>
                  <li class="color-15" data-style="iq-color-15"></li>
                  <li class="color-16" data-style="iq-color-16"></li>
                  <li class="color-17" data-style="iq-color-17"></li>
                  <li class="color-18" data-style="iq-color-18"></li>
                  <li class="color-19" data-style="iq-color-19"></li>
                  <li class="color-20" data-style="iq-color-20"></li>
               </ul>
            </div>
         </div>
      </div>
      <!-- color-customizer END -->
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="<?= assets('js/jquery.min.js') ?>"></script>
      <script src="<?= assets('js/popper.min.js') ?>"></script>
      <script src="<?= assets('js/bootstrap.min.js') ?>"></script>
      <script src="<?= assets('js/jquery.appear.js') ?>"></script>
      <script src="<?= assets('js/countdown.min.js') ?>"></script>
      <script src="<?= assets('js/waypoints.min.js') ?>"></script>
      <script src="<?= assets('js/jquery.counterup.min.js') ?>"></script>
      <script src="<?= assets('js/wow.min.js') ?>"></script>
      <script src="<?= assets('js/apexcharts.js') ?>"></script>
      <script src="<?= assets('js/slick.min.js') ?>"></script>
      <script src="<?= assets('js/select2.min.js') ?>"></script>
      <script src="<?= assets('js/owl.carousel.min.js') ?>"></script>
      <script src="<?= assets('js/jquery.magnific-popup.min.js') ?>"></script>
      <script src="<?= assets('js/smooth-scrollbar.js') ?>"></script>
      <script src="<?= assets('js/lottie.js') ?>"></script>
      <script src="<?= assets('js/core.js') ?>"></script>
      <script src="<?= assets('js/charts.js') ?>"></script>
      <script src="<?= assets('js/animated.js') ?>"></script>
      <script src="<?= assets('js/kelly.js') ?>"></script>
      <script src="<?= assets('js/maps.js') ?>"></script>
      <script src="<?= assets('js/worldLow.js') ?>"></script>
      <script src="<?= assets('js/raphael-min.js') ?>"></script>
      <script src="<?= assets('js/morris.js') ?>"></script>
      <script src="<?= assets('js/morris.min.js') ?>"></script>
      <script src="<?= assets('js/flatpickr.js') ?>"></script>
      <script src="<?= assets('js/style-customizer.js') ?>"></script>
      <script src="<?= assets('js/chart-custom.js') ?>"></script>
      <script src="<?= assets('js/custom.js') ?>"></script>
      
      <script type="text/javascript">
        function copy(element) {
            var copyText = document.getElementById(element);
            copyText.select();
            document.execCommand("copy");
        }
      </script>
   </body>

</html>